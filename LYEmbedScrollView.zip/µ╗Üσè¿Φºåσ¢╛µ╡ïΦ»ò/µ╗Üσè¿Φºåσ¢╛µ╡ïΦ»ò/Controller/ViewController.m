//
//  ViewController.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/28.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "ViewController.h"
#import "JourneyListView.h"
#import "JourneyPictureView.h"
#import "JourneyDetailView.h"
#import "LYHeader.h"

@interface ViewController ()<UIScrollViewDelegate,UITableViewDelegate,UICollectionViewDelegate>
@property (weak, nonatomic) IBOutlet JourneyListView *listView;
@property (weak, nonatomic) IBOutlet JourneyPictureView *pictureView;
@property (weak, nonatomic) IBOutlet JourneyDetailView *detailView;
@property (weak, nonatomic) IBOutlet UIScrollView *contentScrollView;
@property (weak, nonatomic) IBOutlet UIScrollView *journeyScrollView;
@property (weak, nonatomic) IBOutlet UIView *titleView;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetUp];
}

- (void)initialSetUp {
    self.listView.tableView.delegate = self;
    self.pictureView.collectionView.delegate = self;
    self.detailView.scrollView.delegate = self;
    [self titleChanged:self.buttons[0]];
    @weakify(self);
    self.journeyScrollView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            @strongify(self);
            [self.journeyScrollView.mj_header endRefreshing];
            [LYProgressHUD showWords:@"请求成功"];
        });
    }];
}

#pragma mark - action
- (IBAction)titleChanged:(UIButton *)sender {
    for (UIButton *button in self.buttons) {
        button.selected = NO;
    }
    sender.selected = YES;
    CGPoint offset = CGPointMake(SCREEN_W *(sender.tag - 10), 0);
    [self.contentScrollView setContentOffset:offset animated:YES];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //判断是否是子视图滚动
    BOOL isContent = (scrollView == self.listView.tableView || scrollView == self.pictureView.collectionView || scrollView == self.detailView.scrollView);
    if (isContent) {
        BOOL isScroll = self.journeyScrollView.contentOffset.y < self.titleView.y;
        CGFloat offsetY = scrollView.contentOffset.y + self.journeyScrollView.contentOffset.y;
        if (isScroll) {
            [self.journeyScrollView setContentOffset:CGPointMake(0, offsetY)];
            [scrollView setContentOffset:CGPointZero];
        } else if (scrollView.contentOffset.y <= 0 && !isScroll) {
            if (self.journeyScrollView.contentOffset.y >= self.titleView.y) {
                [self.journeyScrollView setContentOffset:CGPointMake(0, offsetY)];
            }
        }
    } else if (scrollView == self.journeyScrollView) {
        if (self.journeyScrollView.contentOffset.y >= self.titleView.y) {
            [self.journeyScrollView setContentOffset:CGPointMake(0, self.titleView.y)];
        }
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    //处理因子视图向下拖拽而导致父视图无法回到原位置
    BOOL isContent = (scrollView == self.listView.tableView || scrollView == self.pictureView.collectionView || scrollView == self.detailView.scrollView);
    if (isContent) {
        CGFloat offsetY = self.journeyScrollView.contentOffset.y;
        if (offsetY < 0) {
            [self.journeyScrollView setContentOffset:CGPointZero
                                            animated:YES];
        }
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.contentScrollView) {
        NSInteger tag = (scrollView.contentOffset.x / SCREEN_W) + 10;
        for (UIButton *button in self.buttons) {
            button.selected = (button.tag == tag);
        }
    }
}

@end
