//
//  LYHeader.h
//  滚动视图测试
//
//  Created by 吕师 on 16/7/28.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#ifndef LYHeader_h
#define LYHeader_h

#import "UIView+Extension.h"
#import "XXNibBridge.h"
#import "UIImage+Extension.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"
#import "SVProgressHUD.h"
#import "LYProgressHUD.h"

#define SCREEN_W [UIScreen mainScreen].bounds.size.width
#define SCREEN_H [UIScreen mainScreen].bounds.size.height
#define NAVIGATION_H 64.0f
#define TITLE_H 40

#ifndef weakify
#if DEBUG
#if __has_feature(objc_arc)
#define weakify(object) autoreleasepool{} __weak __typeof__(object) weak##_##object = object;
#else
#define weakify(object) autoreleasepool{} __block __typeof__(object) block##_##object = object;
#endif
#else
#if __has_feature(objc_arc)
#define weakify(object) try{} @finally{} {} __weak __typeof__(object) weak##_##object = object;
#else
#define weakify(object) try{} @finally{} {} __block __typeof__(object) block##_##object = object;
#endif
#endif
#endif

#ifndef strongify
#if DEBUG
#if __has_feature(objc_arc)
#define strongify(object) autoreleasepool{} __typeof__(object) object = weak##_##object;
#else
#define strongify(object) autoreleasepool{} __typeof__(object) object = block##_##object;
#endif
#else
#if __has_feature(objc_arc)
#define strongify(object) try{} @finally{} __typeof__(object) object = weak##_##object;
#else
#define strongify(object) try{} @finally{} __typeof__(object) object = block##_##object;
#endif
#endif
#endif

#endif /* LYHeader_h */
