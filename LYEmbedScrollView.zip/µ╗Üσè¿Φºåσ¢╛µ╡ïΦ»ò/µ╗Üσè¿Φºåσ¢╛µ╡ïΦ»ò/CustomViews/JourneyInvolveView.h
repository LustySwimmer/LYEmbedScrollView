//
//  JourneyInvolveView.h
//  滚动视图测试
//
//  Created by 吕师 on 16/7/28.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XXNibBridge.h"

@interface JourneyInvolveView : UIView<XXNibBridge>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
