//
//  JourneyDetailView.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/29.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "JourneyDetailView.h"

@implementation JourneyDetailView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
