//
//  JourneyPictureLayout.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/28.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "JourneyPictureLayout.h"
#import "LYHeader.h"

@implementation JourneyPictureLayout

- (void)prepareLayout {
    [super prepareLayout];
    self.scrollDirection = UICollectionViewScrollDirectionVertical;
    self.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    self.minimumLineSpacing = 10;
    self.minimumInteritemSpacing = 10;
    CGFloat width = (SCREEN_W - 30) / 2;
    self.itemSize = CGSizeMake(width, width);
}

@end
