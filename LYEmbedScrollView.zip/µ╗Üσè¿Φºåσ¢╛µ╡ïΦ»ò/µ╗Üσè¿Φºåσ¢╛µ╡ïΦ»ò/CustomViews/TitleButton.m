//
//  TitleButton.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/29.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "TitleButton.h"
#import "LYHeader.h"

@implementation TitleButton

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initialSubView];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self initialSubView];
    }
    return self;
}

- (void)initialSubView {
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
    self.imageView.contentMode = UIViewContentModeScaleToFill;
    self.imageView.layer.masksToBounds = YES;
    self.imageView.layer.cornerRadius = 2.5;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.titleLabel sizeToFit];
    self.titleLabel.centerX = self.width / 2;
    self.titleLabel.centerY = self.height / 2 - 5;
    self.imageView.y = self.titleLabel.bottom + 5;
    self.imageView.width = self.titleLabel.width;
    self.imageView.centerX = self.width / 2;
    self.imageView.height = 5;
}

@end
