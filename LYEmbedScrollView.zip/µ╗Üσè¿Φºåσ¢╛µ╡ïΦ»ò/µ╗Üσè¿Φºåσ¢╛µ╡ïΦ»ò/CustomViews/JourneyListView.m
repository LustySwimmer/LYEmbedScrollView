//
//  JourneyListView.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/28.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "JourneyListView.h"
#import "JourneyTableViewCell.h"
#import "LYHeader.h"

@interface JourneyListView ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation JourneyListView

- (void)awakeFromNib {
    [self.tableView registerNib:[UINib nibWithNibName:@"JourneyTableViewCell" bundle:nil] forCellReuseIdentifier:@"JourneyTableViewCell"];
    @weakify(self);
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            @strongify(self);
            [self.tableView.mj_footer endRefreshing];
            [LYProgressHUD showWords:@"请求成功"];
        });
    }];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    JourneyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"JourneyTableViewCell"];
    return cell;
}

@end
