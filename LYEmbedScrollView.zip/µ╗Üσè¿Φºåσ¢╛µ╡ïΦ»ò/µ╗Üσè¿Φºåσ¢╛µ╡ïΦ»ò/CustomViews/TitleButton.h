//
//  TitleButton.h
//  滚动视图测试
//
//  Created by 吕师 on 16/7/29.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface TitleButton : UIButton

@end
