//
//  JourneyInvolveView.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/28.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "JourneyInvolveView.h"
#import "JourneyCollectionViewCell.h"

@interface JourneyInvolveView ()<UICollectionViewDataSource,UICollectionViewDelegate>

@end

@implementation JourneyInvolveView

- (void)awakeFromNib {
    [self.collectionView registerNib:[UINib nibWithNibName:@"JourneyCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"JourneyCollectionViewCell"];
}


#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 10;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    JourneyCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"JourneyCollectionViewCell" forIndexPath:indexPath];
    return cell;
}

@end
