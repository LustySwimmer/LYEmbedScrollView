//
//  LYRefreshFooter.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/31.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "LYRefreshFooter.h"

@implementation LYRefreshFooter

- (void)prepare {
    [super prepare];
    
}

@end
