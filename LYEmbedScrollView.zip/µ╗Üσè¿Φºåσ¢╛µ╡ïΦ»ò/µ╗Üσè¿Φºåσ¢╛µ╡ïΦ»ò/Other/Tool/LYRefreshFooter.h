//
//  LYRefreshFooter.h
//  滚动视图测试
//
//  Created by 吕师 on 16/7/31.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface LYRefreshFooter : MJRefreshAutoGifFooter

@end
