//
//  LYProgressHUD.h
//  滚动视图测试
//
//  Created by 吕师 on 16/7/31.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import <MBProgressHUD/MBProgressHUD.h>

NS_ASSUME_NONNULL_BEGIN
@interface LYProgressHUD : MBProgressHUD

+ (void)showWords:(NSString *)text;
+ (void)showWords:(NSString *)words toView:(nullable UIView *)view;

@end
NS_ASSUME_NONNULL_END
