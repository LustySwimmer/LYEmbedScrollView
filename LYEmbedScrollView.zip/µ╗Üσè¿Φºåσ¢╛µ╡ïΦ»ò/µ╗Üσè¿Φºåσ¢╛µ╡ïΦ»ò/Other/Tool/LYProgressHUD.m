//
//  LYProgressHUD.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/31.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "LYProgressHUD.h"

@implementation LYProgressHUD

+ (void)showWords:(NSString *)text {
    [self showWords:text toView:nil];
}

+ (void)showWords:(NSString *)words toView:(UIView *)view {
    if (![words length]) { return; }
    if (view == nil) {
        view = [[UIApplication sharedApplication].delegate performSelector:@selector(window)];
    }
    LYProgressHUD *hud = [self showHUDAddedTo:view animated:YES];
    hud.labelFont = [UIFont systemFontOfSize:17];
    hud.labelText = words;
    hud.margin = 5;
    hud.cornerRadius = 5;
    hud.mode = MBProgressHUDModeCustomView;
    hud.removeFromSuperViewOnHide = YES;
    [hud hide:YES afterDelay:1.5];
}

@end
