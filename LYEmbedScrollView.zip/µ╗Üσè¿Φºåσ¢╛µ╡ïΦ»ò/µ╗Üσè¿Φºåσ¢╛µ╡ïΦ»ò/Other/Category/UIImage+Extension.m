//
//  UIImage+Extension.m
//  滚动视图测试
//
//  Created by 吕师 on 16/7/29.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "UIImage+Extension.h"

@implementation UIImage (Extension)

//  颜色转换为背景图片
+ (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0, 0, 20, 20);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}

@end
